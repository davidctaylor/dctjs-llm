import { Component } from '@angular/core';

@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.component.html',
  styleUrls: ['./instructions.component.scss']
})
export class InstructionsComponent {
  public showInstructions = true;

  public toggle(): void {
    this.showInstructions = !this.showInstructions;
  }
}
